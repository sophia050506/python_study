print(r"this's my computer")
print('''this's test 


the end ''')