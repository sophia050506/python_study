import math
for i in range(10):
    print(i)

i = 1
while i < 10:
    print(i)
    i += 1



print(round(3.6),round(-3.6))   
print(abs(-45),abs(1.3))