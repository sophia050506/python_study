import sys

PASSWORDS = {'email':'qwedsfgvvc',
             'blog':'ijngfshgcssvchsgueyd',
             'luggage':'123456'}
if len(sys.argv) < 2:
    print()
    sys.exit()